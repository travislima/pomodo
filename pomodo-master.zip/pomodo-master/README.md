## Hello!👋 Welcome to Pomodo (or Pomo.do - I am not quite sure yet).

I plan to make a To Do list web app that integrates with a [Pomodoro Timer](https://francescocirillo.com/pages/pomodoro-technique) - hence the name "Pomo" and "Do" . In any case, I thought it was quite clever.

If I had my way, I would love to see this app launched to the public. That's it for now. If you know your way around HTML, CSS and JS, please feel free to contribute to this project. You can push all commits to the [Dev Branch](https://github.com/travislima/pomodo/tree/dev) of this repository.

I have not quite decided on a license as yet, since it is still in the very early stages.

Chat soon! 🤘

![Screenshot](screenshot.png)
